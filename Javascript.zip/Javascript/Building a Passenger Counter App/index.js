// let count=0;
// let countEl=document.getElementById("count-el");
// let peopleEntered = document.getElementById("save-el");
// function increment(){
//     count += 1;
//     countEl.textContent = count; 
// }

// function save(){
//     let entries = count + ' - ';
//     peopleEntered.textContent +=entries;
//    countEl.innerText = 0;
//    count =0;
// }


let errorParagraph = document.getElementById("error");
function purchase(){
errorParagraph.textContent = "Something went wrong, please try again"
}




